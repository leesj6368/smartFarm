<?php
// update_watering_info.php

// Database connection
$servername = "localhost";
$username = "planter"; // Your MySQL username
$password = "1234"; // Your MySQL password
$dbname = "smart_planter"; // Your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Logic to water the plant (you can customize this part based on your requirements)

// For demo purposes, let's just update the last_watered_at timestamp
$currentDateTime = date('Y-m-d H:i:s');
$sql = "UPDATE watering_info SET last_watered_at='$currentDateTime'";
if ($conn->query($sql) === TRUE) {
    echo json_encode(array('success' => true));
} else {
    echo json_encode(array('success' => false));
}

$conn->close();
?>
