<?php
// Database connection
$servername = "localhost";
$username = "planter"; // Your MySQL username
$password = "1234"; // Your MySQL password
$dbname = "smart_planter"; // Your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(array('success' => false, 'error' => 'Connection failed: ' . $conn->connect_error));
    exit();
}

// Fetch diary entries
$sql = "SELECT title, content, created_at FROM diary_entries ORDER BY created_at DESC";
$result = $conn->query($sql);

$entries = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $entries[] = $row;
    }
}

// Close connection
$conn->close();

// Return entries in JSON format
echo json_encode(array('success' => true, 'entries' => $entries));
?>
