<?php
// Database connection
$servername = "localhost";
$username = "planter"; // Your MySQL username
$password = "1234"; // Your MySQL password
$dbname = "smart_planter"; // Your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get watering info
$sql = "SELECT * FROM watering_info";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetching and returning data
    $row = $result->fetch_assoc();
    $data = array(
        'last_watered_at' => $row['last_watered_at'],
        'next_watering_at' => $row['next_watering_at'],
        'watering_interval' => $row['watering_interval']
    );
    echo json_encode(array('success' => true, 'data' => $data));
} else {
    echo json_encode(array('success' => false));
}

$conn->close();
?>
