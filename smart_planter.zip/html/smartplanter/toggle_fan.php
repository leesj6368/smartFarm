<?php
// Database connection
$servername = "localhost";
$username = "planter"; // Your MySQL username
$password = "1234"; // Your MySQL password
$dbname = "smart_planter"; // Your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(array('success' => false, 'error' => 'Connection failed: ' . $conn->connect_error));
    exit();
}

// Logic to toggle fan status
$sql = "SELECT fan_status FROM fan_control_info";
$result = $conn->query($sql);

$output = shell_exec('sudo /home/pi/fanon 2>&1');

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $currentStatus = $row['fan_status'];
    $newStatus = ($currentStatus == 'on') ? 'off' : 'on';
    $updateSql = "UPDATE fan_control_info SET fan_status='$newStatus'";

    if ($conn->query($updateSql) === TRUE) {
        echo json_encode(array('success' => true));
    } else {
        echo json_encode(array('success' => false, 'error' => 'Update failed: ' . $conn->error));
    }
} else {
    echo json_encode(array('success' => false, 'error' => 'No records found'));
}

$conn->close();
?>
