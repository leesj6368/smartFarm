<?php
// 이미지 파일이 있는 디렉토리 경로
$imageDirectory = 'image/';

// 이미지 파일 목록을 담을 배열
$imageList = [];

// 이미지 파일 목록을 가져와서 배열에 추가
$images = glob($imageDirectory . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);
foreach ($images as $image) {
    $imageList[] = $image;
}

// JSON 형식으로 이미지 파일 목록 반환
echo json_encode($imageList);
?>
