<?php
// Database connection
$servername = "localhost";
$username = "planter"; // Your MySQL username
$password = "1234"; // Your MySQL password
$dbname = "smart_planter"; // Your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);
$interval = $input['interval'];

// Update watering interval
$sql = "UPDATE watering_info SET watering_interval='$interval', next_watering_at=DATE_ADD(NOW(), INTERVAL $interval DAY)";
if ($conn->query($sql) === TRUE) {
    echo json_encode(array('success' => true));
} else {
    echo json_encode(array('success' => false, 'error' => $conn->error));
}

$conn->close();
?>
