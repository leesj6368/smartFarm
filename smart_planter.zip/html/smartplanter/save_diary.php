<?php
header('Content-Type: application/json');

// 데이터베이스 연결 정보
$servername = "localhost";
$username = "planter";
$password = "1234";
$dbname = "smart_planter";

// 요청 본문에서 다이어리 데이터를 읽음
$input = json_decode(file_get_contents('php://input'), true);

if (isset($input['title']) && isset($input['diary'])) {
    $title = $input['title'];
    $content = $input['diary'];

    // 데이터베이스 연결
    $conn = new mysqli($servername, $username, $password, $dbname);

    // 연결 확인
    if ($conn->connect_error) {
        echo json_encode(['success' => false, 'message' => 'DB 연결 실패: ' . $conn->connect_error]);
        exit();
    }

    // 다이어리 저장 쿼리
    $stmt = $conn->prepare("INSERT INTO diary_entries (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'DB 저장 실패: ' . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => '유효하지 않은 입력']);
}
?>
