<?php
header('Content-Type: application/json');

// 데이터베이스 연결 정보
$servername = "localhost";
$username = "planter";
$password = "1234";
$dbname = "smart_planter";

// 데이터베이스 연결
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 확인
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'DB 연결 실패: ' . $conn->connect_error]);
    exit();
}

// 최신 10개의 환경 데이터 가져10 오기
$sql = "SELECT temperature, humidity, light, recorded_at FROM environment_data ORDER BY recorded_at DESC LIMIT 10";
$result = $conn->query($sql);

$data = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $data]);
} else {
    echo json_encode(['success' => false, 'message' => '데이터 없음']);
}

$conn->close();
?>
