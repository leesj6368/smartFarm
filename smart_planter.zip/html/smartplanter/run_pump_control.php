<?php
// run_pump_control.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Run the pump control program with sudo
$output = shell_exec('sudo /home/pi/pump_control 2>&1');

// Return output in JSON format
echo json_encode(array(
    'success' => true,
    'output' => $output,
));
?>
