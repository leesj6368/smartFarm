#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <wiringPi.h>
#include <mysql/mysql.h>

#define FAN 22 // BCM_GPIO 6

void sig_handler(int signo); // 종료 시그널 처리 함수

int main(void) {
    signal(SIGINT, (void *)sig_handler); // 시그널 핸들러

    // WiringPi 초기화
    if (wiringPiSetup() == -1) {
        fprintf(stdout, "Unable to start wiringPi: %s\n", strerror(errno));
        return 1;
    }
    pinMode(FAN, OUTPUT);

    // MySQL 연결 설정
    MYSQL *conn;
    MYSQL_RES *res;
    MYSQL_ROW row;

    conn = mysql_init(NULL);
    if (conn == NULL) {
        fprintf(stderr, "mysql_init() failed\n");
        return EXIT_FAILURE;
    }

    if (mysql_real_connect(conn, "localhost", "planter", "1234", "smart_planter", 0, NULL, 0) == NULL) {
        fprintf(stderr, "mysql_real_connect() failed: %s\n", mysql_error(conn));
        mysql_close(conn);
        return EXIT_FAILURE;
    }

    // fan_status 조회
    if (mysql_query(conn, "SELECT fan_status FROM fan_control_info")) {
        fprintf(stderr, "SELECT query failed: %s\n", mysql_error(conn));
        mysql_close(conn);
        return EXIT_FAILURE;
    }

    res = mysql_store_result(conn);
    if (res == NULL) {
        fprintf(stderr, "mysql_store_result() failed: %s\n", mysql_error(conn));
        mysql_close(conn);
        return EXIT_FAILURE;
    }

    // 팬 상태 제어
    if ((row = mysql_fetch_row(res)) != NULL) {
        if (strcmp(row[0], "on") == 0) {
            printf("팬 ON 상태\n");
            digitalWrite(FAN, HIGH); // FAN On
        } else {
            printf("팬 OFF 상태\n");
            digitalWrite(FAN, LOW); // FAN Off
        }
    }

    mysql_free_result(res);
    mysql_close(conn);

    return 0;
}

void sig_handler(int signo) {
    printf("프로그램 종료 중, 팬 Off 설정\n");
    digitalWrite(FAN, LOW); // Off
    exit(0);
}
