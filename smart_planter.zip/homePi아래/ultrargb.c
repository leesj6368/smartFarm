#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <wiringPi.h>

#define trigPin 1      // GPIO 26, pin 5 of J25
#define echoPin 29       // GPIO 23, pin 3 of J16
#define RGBLEDPOWER  24 // BCM_GPIO 19
#define RED 27
#define GREEN 28
#define BLUE 29

void sig_handler(int signo); // SIGINT 핸들러 함수
void setup();
void loop();
void checkDistanceAndControlLED();
void turnOffRGBLED();

volatile int rgbLEDTimer = 0;

int main(void) {
    signal(SIGINT, (void *)sig_handler); // 시그널 핸들러 함수

    if (wiringPiSetup() == -1) {
        fprintf(stdout, "Unable to start wiringPi: %s\n", strerror(errno));
        return 1;
    }

    setup();

    while (1) {
        loop();
    }

    return 0;
}

void setup() {
    pinMode(RGBLEDPOWER, OUTPUT);
    pinMode(RED, OUTPUT);
    pinMode(GREEN, OUTPUT);
    pinMode(BLUE, OUTPUT);
    pinMode(trigPin, OUTPUT);
    pinMode(echoPin, INPUT);

    digitalWrite(RGBLEDPOWER, 1); // RGB LED 전원 켜기
    digitalWrite(RED, 0);
    digitalWrite(GREEN, 0);
    digitalWrite(BLUE, 0);
}

void loop() {
    checkDistanceAndControlLED();
    delay(200); // 0.2초마다 체크

    if (rgbLEDTimer > 0) {
        rgbLEDTimer--;
        if (rgbLEDTimer == 0) {
            turnOffRGBLED();
        }
    }
}

void checkDistanceAndControlLED() {
    long startTime, travelTime;
    int distance;

    digitalWrite(trigPin, LOW);
    usleep(2);
    digitalWrite(trigPin, HIGH);
    usleep(10); // 트리거 펄스를 10 마이크로초로 변경
    digitalWrite(trigPin, LOW);

    while (digitalRead(echoPin) == LOW);
    startTime = micros();

    while (digitalRead(echoPin) == HIGH);
    travelTime = micros() - startTime;

    distance = travelTime / 58;

    printf("Distance: %dcm\n", distance);

    if (distance < 10) {
        // 거리가 10cm 이하일 때 RGB LED 켜기
        digitalWrite(RED, 1);
        digitalWrite(GREEN, 1);
        digitalWrite(BLUE, 1);
        rgbLEDTimer = 15 * 5; // 15초 타이머 설정 (200ms 단위)
    } else {
        // 거리가 10cm 이상일 때 LED 끄기
        digitalWrite(RED, 0);
        digitalWrite(GREEN, 0);
        digitalWrite(BLUE, 0);
    }
}

void turnOffRGBLED() {
    digitalWrite(RED, 0);
    digitalWrite(GREEN, 0);
    digitalWrite(BLUE, 0);
}

void sig_handler(int signo) {
    printf("Process stop\n");

    digitalWrite(RED, 0);
    digitalWrite(GREEN, 0);
    digitalWrite(BLUE, 0);
    digitalWrite(RGBLEDPOWER, 0); // Off

    exit(0);
}

